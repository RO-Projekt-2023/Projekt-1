@extends('navbar')


@section('content')
    @extends('carusel')
@endsection