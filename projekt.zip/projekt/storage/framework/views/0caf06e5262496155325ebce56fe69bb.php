<div class="comedian-image">
    <img src="<?php echo e(asset('images/comedian.jpg')); ?>" alt="comedian">
</div>
<div class="main-show-homepage">
    <h2 class="homepage-main-text">DOGODKI</h2>
    <div class="main-show-homepage-carusel">
        <div id="carouselExampleControls" class="carousel slide w-100" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="<?php echo e(asset('images/prva.jpeg')); ?>" class="d-block w-100" alt="...">
               <div class="carousel-caption d-none d-md-block">
                    <h5>Ime dogodka</h5>
                    <p>25.10.2023, ob 17. uri</p>
                </div>
            </div>
            <div class="carousel-item">
              <img src="<?php echo e(asset('images/druga.png')); ?>" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="<?php echo e(asset('images/prva.jpeg')); ?>" class="d-block w-100" alt="...">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
    </div>
</div><?php /**PATH /Volumes/CrucialM2/Projekti/Projekt-1/projekt/resources/views/carusel.blade.php ENDPATH**/ ?>